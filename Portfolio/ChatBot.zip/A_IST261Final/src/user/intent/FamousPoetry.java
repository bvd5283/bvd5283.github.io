/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user.intent;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * Bingnan Dong
 */
public class FamousPoetry  extends AbstractUserIntent{
     public FamousPoetry (String userMsg)  {
		super(userMsg);
	}
     public Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg){
            Hashtable<String, Object> result = new Hashtable<String, Object>();
	     
            /* identify required information: poem number*/
             Pattern pattern = Pattern.compile("[0-9]+");
             Matcher isNum = pattern.matcher(userMsg);
             if (isNum.matches()) {
               if(Integer.valueOf(userMsg)>=1 && Integer.valueOf(userMsg)<=50){
                    result.put("poemNumber",userMsg);
               }
             }
             /* identify option information: friendship*/
             if (userMsg.toLowerCase().contains("friendship")){
                  result.put("poemType", "friendship"); 
                 
             }
              /* identify option information:moon*/
             if (userMsg.toLowerCase().contains("moon")){
                  result.put("poemType", "moon"); 
                  
              }
            
             return result;
	}		
}
