/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user.intent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import chatbot.component.LanguageUnderstander;
/**
 *
 * @Binnan Dong
 */
public abstract class AbstractUserIntent  {
    Hashtable<String, Object> slotTable;
    ArrayList<String> cityList = new ArrayList();
    private String userInput;
	public String getIntentName() {
               System.out.println("IntentName:"+ this.getClass().getSimpleName());
		return this.getClass().getSimpleName();
	}
       abstract Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg); 
       public void updateSlotValues(String newMsg){
		Hashtable<String, Object> localTable = extractSlotValuesFromUserMsg(newMsg);
		//System.out.println(localTable.size());
               
                if(!localTable.isEmpty()) {  //localTable!=null 
                    
                   for(String nowKey: localTable.keySet()) {
				System.out.println("Update Slot:"+ " "+  nowKey+" = "+localTable.get(nowKey));
				if(nowKey!=null&&localTable.get(nowKey)!=null) {
					//System.out.println(nowKey+", "+localTable.get(nowKey));
					slotTable.put(nowKey, localTable.get(nowKey));
				}	
			}
		}
            
               else{   // in order to identify a new indent
                    this.slotTable = new Hashtable<String, Object>(); 
               }
            
	}
	
	public Object getLastestSlotValue(String slotName){
		//updateSlotValues();
		//System.out.println(slotName);
		return slotTable.get(slotName);
	}
	
	public Hashtable<String, Object> getLatestSlotValues(){
		//updateSlotValues();
		return slotTable;
	}
	
	public AbstractUserIntent(String userMsg)  {
             
		this.slotTable = new Hashtable<String, Object>();
                updateSlotValues(userMsg);
            
	}
}
