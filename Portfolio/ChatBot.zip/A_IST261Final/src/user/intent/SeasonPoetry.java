/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user.intent;

import java.util.Hashtable;

/**
 *
 * @Bingnan Dong
 */
public class SeasonPoetry  extends AbstractUserIntent{
     public SeasonPoetry (String userMsg)  {
		super(userMsg);
	}
     public Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg){
            Hashtable<String, Object> result = new Hashtable<String, Object>();
	     String[] season = {"spring","summer","autumn","fall","winter"};
             
             for(int i =0 ; i <season.length ;i++)
             if (userMsg.toLowerCase().contains(season[i])){
                  result.put("season", season[i]); 
                  break;
             }
            
             return result;
	}	
}
