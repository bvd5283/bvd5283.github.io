/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user.intent;

import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @Bingnan Dong
 */
public class FamousPoet extends AbstractUserIntent{
    public FamousPoet (String userMsg)  {
		super(userMsg);
	}	
 // @Override
 	public Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg){
            Hashtable<String, Object> result = new Hashtable<String, Object>();
		
             if (userMsg.toLowerCase().contains("li bai")){
                  result.put("name", "Li Bai"); 
             }
             else if (userMsg.toLowerCase().contains("du fu")){
                 result.put("name", "Du Fu"); 
                
              }
              else if (userMsg.toLowerCase().contains("bai juyi")){
                  result.put("name", "Bai Juyi"); 
                 
              }
             else if (userMsg.toLowerCase().contains("wang wei")){
                  result.put("name", "Wang Wei"); 
                
              }
              else if (userMsg.toLowerCase().contains("liu yuxi")){
                  result.put("name", "Liu Yuxi");  
              }
             if( result.get("name")!=null)
                 if (slotTable.get("poetNumber")!=null){
                       slotTable.remove("poetNumber");
                 }
             
             Pattern pattern = Pattern.compile("[0-9]+");
             Matcher isNum = pattern.matcher(userMsg);
             if (isNum.matches()) {
               if(Integer.valueOf(userMsg)>=1 && Integer.valueOf(userMsg)<=5){
                    result.put("poetNumber",userMsg);
                    // System.out.println("poetNumber:"+ poetNumber );
               }
             }
             
             if(result.isEmpty()){
                if( slotTable.get("name")!=null){
                      result.put("name", slotTable.get("name")); 
                      slotTable.remove("poetNumber");
                }
             }
             
           
            return result;
	}		
}
