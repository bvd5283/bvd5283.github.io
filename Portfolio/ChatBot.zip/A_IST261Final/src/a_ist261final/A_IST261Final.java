/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_ist261final;

import chatbot.infra.Chatbot;
import chatbot.infra.ChatbotGUI;

/**
 *
 * @author Binnan Dong
 */
public class A_IST261Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Chatbot nowChatbot = new Chatbot("Eric", "Chatbot");
		
	ChatbotGUI nowChatbotGUI = new ChatbotGUI(nowChatbot);
    }
    
}
