/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot.infra;

import chatbot.component.DialogManager;
import chatbot.component.LanguageUnderstander;
import chatbot.component.ResponseGenerator;
import java.io.FileNotFoundException;
import user.intent.AbstractUserIntent;

public class Chatbot {
	
	private String userName = "Eric";
	private String botName = "Chatbot";
	
	private LanguageUnderstander lu;
	private DialogManager dm;
	private ResponseGenerator rg;
	
	
	public Chatbot(String userName, String botName) {
		
		this.userName = userName;
		this.botName = botName;
		
		this.lu = new LanguageUnderstander(this);
		this.dm = new DialogManager(this);
		this.rg = new ResponseGenerator(this);
		
	}
	
	public String getResponse(String nowInputText) {
		
		AbstractUserIntent nowUserIntent = lu.getLatestUserIntent(nowInputText);
		if(nowUserIntent!=null) {
			System.out.println("Latest User Intent: "+nowUserIntent.getIntentName());
		}else {
			System.out.println("Latest User Intent: no intent detected yet");
		}
		
		String nowConversationalAction = dm.getConversationalAction(nowUserIntent);
		System.out.println("nowConversationalAction: "+nowConversationalAction);
		
		String finalResponse = rg.getResponse(nowUserIntent, nowConversationalAction);
                
		/*if(finalResponse.equals("answer")){
                    this.lu = new LanguageUnderstander(this);
		    this.dm = new DialogManager(this);
		    this.rg = new ResponseGenerator(this);
                  
                }*/
                
		return finalResponse;

	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getBotName() {
		return botName;
	}

	public void setBotName(String botName) {
		this.botName = botName;
	}

	public static int findKeyword(String statement, String goal) {
		
                String phrase = statement.trim().toLowerCase();
		goal = goal.toLowerCase();
                int startPos = 0;
		// The only change to incorporate the startPos is in  the line below
		int psn = phrase.indexOf(goal, startPos);

		// Refinement--make sure the goal isn't part of a word
		while (psn >= 0) {
			// Find the string of length 1 before and after  the word
			String before = " ", after = " ";
			if (psn > 0) {
				before = phrase.substring(psn - 1, psn);
			}
			if (psn + goal.length() < phrase.length()) {
				after = phrase.substring(psn + goal.length(), psn + goal.length() + 1);
			}

			// If before and after aren't letters, we've found the word
			if (((before.compareTo("a") < 0) || (before.compareTo("z") > 0)) // before is not a
																				// letter
					&& ((after.compareTo("a") < 0) || (after.compareTo("z") > 0))) {
				return psn;
			}

			// The last position didn't work, so let's find the next, if there is one.
			psn = phrase.indexOf(goal, psn + 1);

		}

		return -1;
	}


}
	
	



