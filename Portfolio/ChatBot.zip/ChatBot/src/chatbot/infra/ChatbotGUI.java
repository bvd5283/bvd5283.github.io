/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot.infra;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;


import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

public class ChatbotGUI extends JFrame {

	private Chatbot nowChatbot;
	
	private JFrame nowGUIFrame;
	
	private JTextField inputTextBox;
	private JTextPane chatHistoryPane;
		
	public ChatbotGUI(Chatbot nowChatbot) {
		
		this.nowChatbot = nowChatbot;
		
		
		//create the frame of chatbot
		nowGUIFrame = new JFrame();
		nowGUIFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		nowGUIFrame.setVisible(true);
		nowGUIFrame.setResizable(false);
		nowGUIFrame.setLayout(null);
		nowGUIFrame.setSize(580,600);  
                nowGUIFrame.setLocation(300, 80); 
		nowGUIFrame.setTitle("Tang Poetry Chatbot"+"");
              
                nowGUIFrame.getContentPane().setBackground(Color.white); 
               
                //Add image on the top
		ImageIcon img = new ImageIcon("caption.jpg");
                JLabel imgLabel = new JLabel(img);
                imgLabel.setSize(407, 47);
                imgLabel.setLocation(60, 8);
                nowGUIFrame.add( imgLabel);
		
                //create JTextPane
		chatHistoryPane = new JTextPane();
               // chatHistoryPane.setSize(520, 400);
		//chatHistoryPane.setLocation(2, 2);
                //nowGUIFrame.add(chatHistoryPane);
                
                 //add scrollbar for the pane
                JScrollPane scrollPane = new JScrollPane(chatHistoryPane); 
		scrollPane.setSize(550, 410);
                scrollPane.setLocation(10, 75);
                scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS  );
                nowGUIFrame.add(scrollPane);
		
		//create JTextField
		inputTextBox = new JTextField();
		nowGUIFrame.add(inputTextBox);
		inputTextBox.setSize(550, 30);
		inputTextBox.setLocation(10, 510);
		inputTextBox.addActionListener(new InputTextListener(inputTextBox, chatHistoryPane, this));
                
                String  HelloText ="Hello, welcome to the world of Tang Poetry. I will introduce the most famous Tang poems and poets for you. You can also appreciate the beauty of the four seasons in Tang Poetry with me.\n";
                ChatbotGUI.appendToPane(chatHistoryPane, this.getChatbot().getBotName(), HelloText,Color.BLACK);
		
	 	
	}

	public ChatbotGUI() {
		// TODO Auto-generated constructor stub
	}
	
	public Chatbot getChatbot() {
		return nowChatbot;
	}
	
	public static void appendToPane(JTextPane nowPane, String senderName, String message, Color color){
		
		String nowMsg = senderName+": "+message+"\n";
		
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, color);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.FontSize, 12);
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = nowPane.getDocument().getLength();
        nowPane.setCaretPosition(len);
        nowPane.setCharacterAttributes(aset, false);
        nowPane.replaceSelection(nowMsg);
        
    }
	
	
}


class InputTextListener implements ActionListener{
	
	private ChatbotGUI chatbotUtil;
	
	private JTextField nowInputTextBox;
	private JTextPane nowChatHistoryPane;
	
	public InputTextListener(JTextField inputTextBox, JTextPane chatHistoryPane, ChatbotGUI chatbotUtil) {
		this.chatbotUtil = chatbotUtil;
		nowInputTextBox = inputTextBox;
		nowChatHistoryPane = chatHistoryPane;
		//nowUserName = userName;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String nowInputText = nowInputTextBox.getText();
		ChatbotGUI.appendToPane(nowChatHistoryPane, chatbotUtil.getChatbot().getUserName(), nowInputText,Color.BLUE);
		
		String nowChatbotResponse = chatbotUtil.getChatbot().getResponse(nowInputText);
		ChatbotGUI.appendToPane(nowChatHistoryPane, chatbotUtil.getChatbot().getBotName(), nowChatbotResponse, Color.BLACK);
		
		//
		//appendToPane(nowChatHistoryPane, nowMsg, Color.BLUE);
		
		nowInputTextBox.setText("");
		
	}
	
	
}

