/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot.component;
import  chatbot.infra.Chatbot;
import java.util.Random;
import  user.intent.AbstractUserIntent;

public class ResponseGenerator {

	private Chatbot chatbot;
        public  static int count =0;
	
	public ResponseGenerator(Chatbot chatbot) {
	    this.chatbot = chatbot;
	}

  

       public String getResponse(AbstractUserIntent nowUserIntent, String nowConversationalAction) {
           String[] fiftyPoetyResponses ={"1.This is a famous poem written by Meng Haoran.\n "+ "         Spring Morning\n"+ "This spring morning in bed I'm lying,\nNot to awake till birds are crying.\nAfter one night of wind and showers,\nHow many are the fallen flowers!\n",
                                          "2.This is a famous poem written by Liu Zongyuan.\n "+ "        Fishing in Snow\n"+ "From hill to hill no bird in flight,\nFrom path to path no man in sight.\nA straw-cloak’d man afloat, behold!\nIs fishing snow in river cold.\n",
                                          "3.This is a famous poem written by Wang Zhihuan.\n "+ "         On the Stock Tower\n"+ "The sun along the mountains bows,\nThe Yellow River seawards flows.\nYou can enjoy a grander sight,\nIf you climb to a greater height.\n" ,
                                          "4.This is a famous poem written by Li Shangyin.\n "+ "        On The PLain Of Tombs\n"+ "At dusk my heart is filled with glooms,\nI drive my cab to ancient tomb.\nThe setting sun seems so sublime.\nBut it is near its dying time.\n",
                                          "5.This is a famous poem written by He Zhizhang.\n "+ "          Home Coming 1\n"+ "I left home young and not till old do I come back,\nUnchanged my accent, my hair no longer black\nThe children whom I meet do not know who am I.\n“Where are you from, dear sir?” they ask with beaming eye.\n" ,
                                          "6.This is a famous poem written by He Zhizhang.\n "+ "          Home Coming 2\n"+ "Since I left my homeland so many years have passed,\nSo much has faded away and so little can last.\nOnly in Mirror Lake before my oldened door,\nThe vernal wind still ripples waves now as before.\n",
                                          "7.This is a famous poem written by Liu Yuxi.\n "+ "        The Town of Stone\n"+ "The changeless hills round ancient capital still stand,\nWaves beating on ruined walls, unheeded, roll away.\nThe moon which shone by riverside on flourished land.\nStill shiines a dead of night over ruined town today.\n",
                                          "8.This is a famous poem written by Du Mu.\n "+ "         The Red Cliff\n"+ "We dig out broken halberds buried in the sand, \nAnd wash and rub these relics of an ancient war.\nHad the east windrefused General Zhou a helping hand,\nHis foe'd have locked his fair wife on Northern shore.\n" ,
                                          "9.This is a famous poem written by Cui Hao.\n "+ "       Yellow Crane Tower\n"+ "The sage on yellow crane was gone amid clouds white,\nTo what avail is Yellow Crane Tower left here.\nOnce gone, the yellow crane will not on earthlight,\nOnly white clouds still float in vain from year to year.\nBy sunlit river trees can be counted one by one,\nOn parrot Islet sweet green grass grows fast and thick.\nWhere is my native land beyond the setting sun,\nThe mist-veiled waves of River Han makes me homesick.\n",
                                          "10.This is a famous poem written by Li Shangyin.\n "+ "         To the Moon Goddess\n"+ "Upon the marble screen the candelight is winking,\nThe Silver River slants and morning stars are sinking.\nYou'd regret to have stolen the miraculous posion,\nEach night you brood over the lonely celestial ocean.\n",
                                          "11.This is a famous poem written by Li Bai.\n "+ "        The Phoenix Terrance at Jinling\n"+ "On phoenix Terrace once phoenixes came to sing,\nThe birds are gone but still roll on the river's wave.\nThe ruined palace's buried under weeds in spring.\nThe ancient sages in caps and gowns all lie in graves.\nThe three-peaked mountain is half lost in azure sky,\nThe two-forked strem by Egret Isle is kept apart.\nAs floating clouds can veil the bright sun from the eye,\nImperial Court now out of view saddens my heart.\n",
                                          "12.This is a famous poem written by Du Fu.\n "+ "         The Stone Fortess\n"+ "With his exploits history is crowned,\nFor the stone fortress he's renowned.\nThe river flows but stones still stand,\nhough he'd not taken back lost land.\n",
                                          "13.This is a famous poem written by Cui Hu.\n "+ "        Written in a Village South of the Capital\n"+ "In this house on this day last year a pink face vied,\nIn beauty with the pink peach blossom side by side.\nI do not know today where the pink face has gone,\nn vernal breeze still simle pnk peach blossoms full blown.\n",
                                          "14.This is a famous poem written by Li Bai.\n "+ "         A Faithful Wife Longing for Her Husband in Spring\n"+ "Northern grass looks like green silk thread,\nAlready broken is my heart.\nWhen you think of your home on your part,\nAlready broken is my heart.\nVernal wind, intruder unseen,\nO how dare you part my bed screen.\n",
                                          "15.This is a famous poem written by Jia Dao.\n "+ "       A Swordsman\n"+"I've sharpened my sword for ten years,\nI do not know if it will pierce.\nI show its blade to you today,\nO who has any grievance? Say.\n",
                                          "16.This is a famous poem written by Li Yi.\n "+ "      On Hearing a Flute at Night atop the Victor's Wall\n"+"Before the beacon tower sand looks white as snow,\nBeyond the Victor's Wall like frost cold moonbeams flow.\n None knows from where a flute blows a nostalgic song,\nAll warriors like awake homesick the whole night long.\n",
                                          "17.This is a famous poem written by Meng Jiao.\n "+ "       ucessful at the Civil Service Examinations\n"+"Gone are all my past woes, what more have I to say,\nMy body and my mind enjoy their fill today.\nSuccessful, faster runs my horse in vernal breeze,\nI've seen within one day all flowers on the trees.\n",
                                          "18.This is a famous poem written by Wang Changling.\n "+ "         On the Frontier\n"+ "The moon still shines on mountain passes as of yore,\nHow many guardsmen of the Great Wall are no more.\\nIf the Flying General were still there in command,\n No hostile steeds would have dared to invade our land.\n",
                                          "19.This is a famous poem written by Wang Zhihua.\n "+ "       Out of the Great Wall\n"+ "The Yellow River rises to the white cloud,\nThe lonely town is lost amid the mountains proud.\n Why should the Mongol flute complain no willow grow,\nBeyond the Gate of Jade no vernal wind will blow.\n",
                                          "20.This is a famous poem written by Li Bai.\n "+ "         The Moon over the Mountain Pass\n"+ "From Heaven's Peak the moon rises brigh,\nOver a boundless sea of cloud.\nWinds blow for miles with main and might.\nOur warriors march down the frontier.\nWhile Tartars peer across Blue Bays,\nFrom the battlefield outstretched here,\nNone have come back since olden days.\n Guards watch the scene of borderland,\nThinking of home with wistful eyes.\nTonight upstairs their wives would stand,\nLooking afar with longing sighs.\n",
                                          "21.This is a famous poem written by Du Fu.\n "+ "        Temple of the Premier of Shu\n"+"The Premier's Temple's in the shade,\nOf cypress woven with brocade.\nThe steps are green with grass in spring,\nIn vain amid leaves orioles sing.\nConsulted thrice on state affair.\nHe served two reigns beyond compare.\nHe died before he won success,\nCause heroes' tears not wet their dress.\n",
                                          "22.This is a famous poem written by Li Bai.\n "+ "        Endless Longing\n"+ "I long for one in all at royal capital,\nThe autumn cricket wails beside the golden rails.\nLight frost mingled with dew, my mat looks cold in hue,\nMy lonely lamp burns dull, of longing I would die.\nRolling up screens to view the moon,in vain I sigh,\nMy flowerlike Beauty is high up as clouds in the sky.\nAbove, the boundless heaven spreads its canopy screen,\nBelow, the endless river rolls its billows green.\nMy soul can't fly over sky so vast nor streams so wide,\nIn dreams I can't go through mountain pass to her side.\nWe are so far apart,\nThe longing breaks my heart.\n",
                                          "23.This is a famous poem written by Meng Jiao.\n "+ "        Song of the Parting Son\n"+ "From the threads a mother's hand weave,\nA gown for parting son is made.\nSown stitch by stitch before he leaves,\nFor fear his return be delayed.\nSuch kindness as young grass receives,\nFrom the warm sun can't be repaid.\n",
                                          "24.This is a famous poem written by Han Yu.\n "+ "        Written for My Grandnephew at the Blue Pass\n"+ "At dawn to Royal Court a proposal was made,\nAt dusk I’m banished eight thousand li away.\nTo undo the misdeeds I would have given aid,\nDare I have spared myself with powers in decay.\nThe Ridge veiled in barred clouds, where can my home be seen,\nThe Blue Pass clad in snow, my horse won't forward go.\nYou have come from afar and I know what you mean,\nNot to leave my bones there where miastic waves flow.\n",
                                          "25.This is a famous poem written by Cen Shen.\n "+ "        Thinking of Home While Marching on Mountain-Climbing Day \n"+ "Up the mountain I'd force myself to go,\nBut nobody would bring me wine around.\nChrysanthemums of my homeland should blow,\nTo beautify the far-off battleground.\n",
                                          "26.This is a famous poem written by Du Fu.\n "+ "         Thinking of My Brothers on a Moonlit Night\n"+ "War drums break people's journey drear,\nA swan honks on autumn frontier.\nDew turns into frost since tonight,\nThen moon viewed from home is more bright.\nI've brothers scattered here and there,\nFor our life or death none would care.\nLetters can't reach where I intend,\nAlas! The war's not come to and end.\n",
                                          "27.This is a famous poem written by Li Sahngyin.\n "+ "        Written on a Rainy Night to My Wife in the North\n"+ "You ask me when I can return, but I don't know, \nIt rains in western hills and autumn pools overflow.\nWhen can we trim by window side the candlelight,\nAnd talk about the western hills in rainy night.\n",
                                          "28.This is a famous poem written by Li Bai.\n "+ "       Hearing the Flute on a Spring Night in Luoyang\n"+ "From whose house has come the song of jade flute unseen,\nIt fills the town of Luoyang, spread by wind of spring.\nTonight I hear the farewell song of Willow Green,\nTo whom the tune will not nostalgic feeling bring.\n",
                                          "29.This is a famous poem written by Wang Wei.\n "+ "         hinking of My Brothers on Mountain-climbing Day\n"+ "Alone, a lonely stranger in a foreign land,\nI doubly pine for my kinsfolk on holiday.\nI know my brothers would, with dogwood spray in hand\nClimb up the mountain and miss me so far away.\n",
                                          "30.This is a famous poem written by Song Zhiwen.\n "+ "       Crossing River Han\n"+ "I longed for news on the frontier,\nFrom day to day, from year to year.\nNow nearing home, timid I grow,\nI dare not ask what I would know.",
                                          "31.This is a famous poem written by Du Fu.\n "+ "         Thinking of Li Bai on a Spring Day\n"+ "Li Bai is unrivalled in verse,\nHe towers in the universe.\nFresher than Yu on northern shore,\nBrighter than Bao, poet of yore.\nI long for him as longing tree,\nAt sunset will he think of me.\nWhen may we drink a cup of wine,\nAnd talk about prose and verse fine.\n",
                                          "32.This is a famous poem written by Li Bai.\n "+ "        Farewell to Uncle Yun,at Xie Tiao's Pavilion in Xuancheng\n"+ "What left me yesterday,\nCan be retained no more.\nWhat troubles me today,\nIs the times for which I feel sore.\nIn autumn wind for miles and miles the wild geese fly,\nLet's drink in face of this in the pavilion high.\nYour writing's forcible like ancient poets while.\nMine is in Junior Xie's clear and spirited style.\nBoth of us have an ideal high,\nWe would reach the moon in the sky.\nCut running water with a sword, it will faster flow,\nDrink wine to drown your sorrow, it will heavier grow.\nIf we despair of all human affairs,\nLet us roam in a boat with loosened hairs.\n",
                                          "33.This is a famous poem written by Li Bai.\n "+ "        To Wang Lun\n"+ "I, Li Bai, sit in a boat about to go,\nWhen suddenly on shore your farewell songs overflow.\nHowever deep the Lake of Peach Blossoms may be,\nIt's not so deep,\nO Wang Lun, as your love for me.",
                                          "34.This is a famous poem written by Li Bai.\n "+ "        To Wang Changling Banished to the West\n"+ "All willow-down has fallen and sad cuckoos cry,\nTo hear you banished southwestward beyond Five Streams.\nI would confide no sorrow to the moon on high,\nFor it will follow you west of the Land of Dreams.\n",
                                          "35.This is a famous poem written by Du Xunhe.\n "+ "         To Young Pine\n"+ "While young, the pine tree thrusts its head amid tall grass,\nNow by and by we find it outgrow weed in mass.\nPeople don't realize it will grow to scrape the sky,\nSeeing it tower in cloud, then they know it's high.\n",
                                          "36.This is a famous poem written by Wang Wei.\n "+ "       Seeing Li off to Zizhou\n"+ "The trees in your valley scrape the sky,\nYou'll hear in your hills cuckoo's cry.\nIf it rained at night in your mountain,\nYou'd see your tree tips hung like fountain.\nYour women weave to make a suit,\nYou'd try to solve people's dispute.\nThe sage before you opened schools,\nLike him you should carry out rules.\n",
                                          "37.This is a famous poem written by Wang Wei.\n "+ "          At Parting\n"+"Dismounted, I drink with you,\nAnd ask what you've in view.\nI can't do what I will,\nSo I will do what I will.\nI'll ask you no more, friend,\nLet clouds drift without end.",
                                          "38.This is a famous poem written by Wang Changling.\n "+ "        Farewell to Xin Jian at Lotus Tower\n"+ "A cold rain dissolved in East Stream invades the night,\nAt dawn you'll leave the lonely Southern hills in haze.\nIf my friends in the North should ask if I'm all right,\nTell them I'm free from blame as ice in crystal vase.\n",
                                          "39.This is a famous poem written by Zhang Ji.\n "+ "         Mooring by Maple Bridge at Night\n"+ "At moonset cry the crows, streaking the frosty sky,\nDimly lit fishing boats ' neath maples sadly lie.\nBeyond the city wall, from Temple of Cold Hill,\nBells break the ship-borne roamer's dream and midnight still.\n",
                                          "40.This is a famous poem written by Du Mu.\n "+ "       Spring on the Southern Rivershore\n"+ "Orioles sing for miles amid red blooms and green trees,\nBy hills and rills wine shop streamers wave in the breeze.\nFour hundred eighty splendid temples still remain,\nOf Southern Dynasties in the mist and rain.\n",
                                          "41.This is a famous poem written by Bai Juyi.\n "+ "         Peach Blossoms in the Temple of Great Forest\n"+ "All flowers in late spring have fallen far and wide,\nBut peach blossoms are full-blown on this mountainside.\nI oft regret spring's gone without leaving its trace,\nI do not know it's come up to adorn this place.\n",
                                          "42.This is a famous poem written by Wang Bo.\n "+ "        Farewell to Prefect Du\n"+ "You'll leave the town walled far and wide,\nFor mist-veiled land by river side.\nI feel on parting sad and drear,\nFor both of us are strangers here,\nIf you have friends who know your heart,\nDistance cannot keep you apart.\nAt crossroads where we bid adieu,\nDo not shed tears as women do.\n",
                                          "43.This is a famous poem written by Luo Yin.\n "+ "         To the Bee\n"+ "On the plain or atop the hill,\nOf beauty you enjoy your fill.\nYou gather honey from flowers sweet,\nFor whom are you busy and fleet\n",
                                          "44.This is a famous poem written by Li Shangyin.\n "+ "        To the Cicada\n"+ "High, you can't eat your fill,\nIn vain you wait and trill.\nAt dawn you hush your song,\nThe tree is green for long.\nI drift as water flows,\nAnd waste my garden grows.\nThank you for warning due,\nI am as poor as you\n",
                                          "45.This is a famous poem written by Han Yu.\n "+ "         Spring Snow\n"+ "On vernal day no flowers were in bloom, alas!\nIn second moon I’m glad to see the budding grass.\nBut White snow dislikes the late coming vernal breeze,\nIn plays the parting flowers flying through the trees.\n",
                                          "46.This is a famous poem written by Li Shangyin.\n "+ "        The End of the Sky\n"+"Spring is far, far away,\nWhere the sun slants its ray.\nIf orioles have tear,\nWet highest flowers here\n",
                                          "47.This is a famous poem written by Wen Tingyun.\n "+ "          Early Departure on Mount Shang\n"+ "At dawn I rise, with ringing bells my cab goes,\nBut grieved in thoughts of my home,I feel lost.\nAs the moon sets over thatched inn, the cock crown,\nFootprints are left on wood bridge paved with frost.\nThe mountain path is covered with oak leaves,\nThe post-house bright with blooming orange trees.\nThe dream of my homeland last night still grieves,\nA pool of mallards playing with wild geese.\n",
                                          "48.This is a famous poem written by Du Mu.\n "+ "         The Mourning Day\n"+ "A drizzling rain falls like tears on the Mourning Day,\nThe mourner's heart is going to break on his way.\nWhere can a wine shop be found to drown his sad hours,\nA cowherd points to a cot amid apricot flowers.\n",
                                          "49.This is a famous poem written by Luo Binwang.\n "+ "         The Cicada\n"+ "Of autumn the cicada sings,\nIn prison I'm wore out with care.\nHow can I bear its blue black wings,\nWhich remind me of my grey hair.\nHeavy with dew it cannot fly,\nDrowned in the wind, its song's not heard.\nWho would believe its spirit high,\nCould I express my grief in word.\n",
                                          "50.This is a famous poem written by Du Fu.\n "+  "        Spring View\nOn war-torn land streams flow and mountains stand,\nIn towns unquiet grass and weeds run riot.\nGrieved o’ er the years, flowers are moved to tears,\nSeeing us part, birds cry with broken heart.\nThe beacon fire has gone higher and higher,\nWords from household are worth their weight in gold.\nI can not bear to scratch my grizzling hair,\nIt grows too thin to hold a light hairpin.\n",
                                      
           };
           
           String [] moonResponses={  "This is famous moon poem written by Li Bai\n        Thoughts on a Tranquil Night\n"+ "Before my bed a pool of night,\nI wonder if it's frost aground.\nLooking up, I find moon bright,\nBowing, in homesickness, I'm drowned.\n"};
          
           String [] friendshipResponses={"This is a famous friendship poem written by Wang Bo.\n "+ "        Farewell to Prefect Du\n"+ "You'll leave the town walled far and wide,\nFor mist-veiled land by river side.\nI feel on parting sad and drear,\nFor both of us are strangers here,\nIf you have friends who know your heart,\nDistance cannot keep you apart.\nAt crossroads where we bid adieu,\nDo not shed tears as women do.\n", };
          
           String [] LibaiResponses={"1.This is famous poem written by Li Bai\n        The Waterfall in Mount Lu Viewed from Afar\n"+ "The sunlit Censer peak exhales a wreath of cloud,\n"+  "Like an upended stream the cataract sounds loud.\n" +  "Its torrent dashes down three thousand feet from high,\n"+  "As if the Silver River fell from azure sky.\n" ,
                                     "2.This is famous poem written by Li Bai\n        Thoughts on a Tranquil Night\n"+ "Before my bed a pool of night,\nI wonder if it's frost aground.\nLooking up, I find moon bright,\nBowing, in homesickness, I'm drowned.\n",
                                     "3.This is famous poem written by Li Bai\n        Leaving the WHITE KING At Dawn\n"+ "Leaving at dawn the White King crowned with rainbow cloud\nI have sailed a thousand miles through Three Georges in a day.\nWith monkeys' sad adieus the riverbanks are loud,\nMy boat has left ten thousand mountains far away.\n",
                                     "4.This is famous poem written by Li Bai\n        Seeing Meng Haoran off at Yellow Crane Tower\n"+"My friend has left the west where the Yellow Crane towers,\nFor River Town veiled in green willows and red flowers.\nHis lessening sail is lost in boundless blue sky,\nWhere I see but the endless River rolling by.\n",
                                     "5.This is famous poem written by Li Bai\n        Sitting Alone in Jingting Mountain\n"+"All birds have flown away, so high,\nA lonely cloud drifts on, so free.\nWe are not tired, the peak and I,\nNor I of him, nor he of me.\n",
             
                           };
           String [] DufuResponses={ "1.This is a famous poem written by Du Fu\n        Spring View\n"+ "On war-torn land streams flow and mountains stand,\nIn towns unquiet grass and weeds run riot.\nGrieved o’ er the years, flowers are moved to tears,\nSeeing us part, birds cry with broken heart.\nThe beacon fire has gone higher and higher,\nWords from household are worth their weight in gold.\nI can not bear to scratch my grizzling hair,\nIt grows too thin to hold a light hairpin.\n",
                                     "2.This is a famous poem written by Du Fu\n        A QUATRAIN\n" +"Two golden orioles sing amid the willows green,\nA flock of white egrets flies into the blue sky.\nMy window frames the snow-crowned western mountain scene,\nMy door oft says to eastward-going ships \"Goodbye!\"\n",
                                     "3.This is a famous poem written by Du Fu\n        Strolling Alone among Flowers by Riverside\n"+"Along the Yellow Path flowers are overgrown,\nThousands of them in full blossom weigh branches down.\nButterflies linger, now and then they dance along,\nGolden orioles warble with ease their timely sing.\n",
                                     "4.This is a famous poem written by Du Fu\n       Happy Rain on a Spring Night\n"+"Good rain knows its time right,\nIt will fall when comes spring.\n With wind it steals in night,\nMute, it moistens each thing.\nO’er wild lanes dark cloud spreads,\nIn boat a lantern looms.\nDawn sees saturated reds,\nThe town’s heavy with blooms.\n",
                                     "5.This is a famous poem written by Du Fu\n        Watching Mt Tai\n"+"Oh, Mt. Tai, what a height you exhibit?\nFrom Qi and Lu, your greenness still in sight!\nNature favors you with all th’ exquisites,\nYour one side sunlit while th’ other moonlit.\nThe Clouds wreathe you--a great inspiration,\nBird returning home--a haunting vision.\nWhen someday I’m atop your topmost rise,\nBelow, dwarfed, other mountains will all lie.\n",
                           };
           
           String [] WangweiResponses={"1.This is a famous poem written by Wang Wei\n         A Deer Yard\n"+ "On th’ empty hill, no soul is seen,\nYet a man’s voice is heard to ring.\nThe sunshine returns to the wood,\nCreeping back onto the moss green.\n",
                                       "2.This is a famous poem written by Wang Wei\n         Bird Melodies Randomize the Dale\n"+"An idle man hears cassia-blossoms fall,\nA tranquil night brings peace to a spring hill.\nA moonrise surprises a nightingale,\nThat twitters randomly in the spring dale.\n",
                                       "3.This is a famous poem written by Wang Wei\n        A Lodge in the Bamboo Woods\n"+"Alone in the bamboo woods quiet and deep,\nI pluck the zither; a whistle I blow.\nThough no one knows I am in the retreat,\nThe silver moon bestows its shining glow.\n",
                                       "4.This is a famous poem written by Wang Wei\n         Love Seeds\n"+"The red beans grow in southern land,\nHow many load in spring the trees.\nGather them till full is your hand.\nThey revive fond memories.\n",
                                       "5.This is a famous poem written by Wang Wei\n         Seeing Yuan the Second Off to the Northwest Frontier \n"+"No dust is raised on the road wet with morning rain\nThe willows by the hotel look so fresh and green.\nI invite you to drink a cup of wine again,\nWest of the Sunny Pass no more friends will be seen\n",
           };
           String [] BaijuyiResponses={ "1.This is a famous poem written by Bai Juyi\n         Farewell on the Ancient-Old Grassland\n"+"Wild grasses spread o’ er ancient plain,\nWith spring and fall they come and go.\nWild fire can’ t burn them up again,\nThey rise when vernal breezes blow.\n" ,
                                        "2.This is a famous poem written by Bai Juyi\n         White Cloud Fountain\n"+"Behold the White Cloud Fountain on the sky-blue Mountain,\nWhite clouds enjoy pleasure while water enjoys leisure.\nWhy should the torrent dash down from the mountain high,\nAnd overflow the human world with waves far and nigh.\n",
                                        "3.This is a famous poem written by Bai Juyi\n         For Roaming Yuan Zhen\n"+"Your wife gazes at yellowing willows at home,\nYou on flowers falling on the ground while you roam.\nSpring comes to end in two places on the same day,\nYou think of home and she of you far, far away.\n",
                                        "4.This is a famous poem written by Bai Juyi\n         On Qiantang Lake in Spring\n"+"West of Jia Pavilion and north of Lonely Hill,\nWater brims level with the bank and clouds hang low.\nDisputing for sunny trees, early orioles trill,\nPecking vernal mud in, young swallows come and go.\nA riot of blooms begins to dazzle the eye,\nAmid short grass the horse hoofs can barely be seen,\nI love best the east of the lake under the sky,\nThe bank paved with white sand is shaded by willows green.\n",
                                        "5.This is a famous poem written by Bai Juyi\n         Chanting on the River at Dusk\n"+"A waning sunlight beam on the water,\nHalf the river blue and half rufescent.\nWhat delights on this ninth month and third night,\nIs dew like real pearls, the moon a bow bent.\n",
           };
           String [] LiuyuxiResponses={"1.This is a famous poem written by Liu Yuxi\n        Song of Autumn\n"+ "Since olden days we feel in autumn sad and drear,\nBut I say spring cannot compete with autumn clear.\nOn a fine day a crane cleaves the clouds and soars high,\nIt leads the poet’s lofty mind to azure sky.\n",
                                       "2.This is a famous poem written by Liu Yuxi\n        Bamboo Branch Songs-1\n"+ "Between the green willows the river flows along,\nMy gallant in a boat is heard to sing a song.\nThe west is veiled in rain, the east enjoys sunshine,\nMy gallant is as deep in love as the day is fine.\n",
                                       "3.This is a famous poem written by Liu Yuxi\n        Bamboo Branch Songs-2\n"+ "The mountain's red with peach blossoms above,\nThe shore is washed by spring waves below.\nRed blossoms fade fast as my gallant's love,\nThe river like my sorrow will ever flow.\n",
                                       "4.This is a famous poem written by Liu Yuxi\n        The Street of Mansions\n"+ "Besides the Bridge of Birds rank grasses overgrow,\nOver the Street of Mansions the setting sun hangs low.\nSwallows which skimmed by painted eaves in days gone by,\nAre dipping now in homes where humble people occupy.\n",
                                       "5.This is a famous poem written by Liu Yuxi\n        Temple of the King of Shu\n"+"Your heroism under the sky,\nFrom year to year spread far and high.\nLike tripod did three kingdoms reign,\nOld royal coins were used again.\nYour premier struck your kingdom's root,\nBut your son did not follow suit.\nEven western dancers felt sad,\nTo make Northern conquerors glad.\n",
           };
           
           
           String [] SpringResponses={"1.Let us appreciate the beauty of spring in the poem written by Meng Haoran.\n "+ "         Spring Morning\n"+"This spring morning in bed I'm lying,\nNot to awake till birds are crying.\nAfter one night of wind and showers,\nHow many are the fallen flowers!\n",
                                      "2.Let us appreciate the beauty of spring in the poem written by He Zhizhang.\n "+ "       The Willow\n"+"The slender beauty's dressed in emerald all about,\nA thousand branches droop like fringes made of jade.\nBut do you know by whom these slim leaves are cut out,\nThe wind of early spring is sharp as scissor blade.\n",
                                      "3.Let us appreciate the beauty of spring in the poem written by Han Yu.\n "+ "        Early Spring\n"+ "A drizzle coats the capital like cream,\nWhere grass can be seen from afar, but not close.\nThis spring scene, of the year, is the best time,\nBetter than the town in willow-lavish prime.\n",
                                      "4.Let us appreciate the beauty of spring in the poem written by Bai Juyi.\n "+ "        Fabulous South\n"+ "Fabulous south,\nFamiliar scene.\nThe rising sun dyes the water blazingly red,\nThe spring radiance paints the water azure blue.\nHow can I not miss the south?\n",
                                      "5.Let us appreciate the beauty of spring in the poem written by Bai Juyi.\n "+ "        Farewell on the Ancient-Old Grassland\n"+ "Verdant and lush grass on the plain,\nShrivels and thrives each year again.\nWild fire cannot kill it at all.\nSpring breezes will bring it back tall.\n",
                  
                           };
           String [] SummerResponses={"1.Let us appreciate the beauty of summer in the poem written by Meng Haoran\n "+ "         Thinking of Xin the Eldest by the Poolside on a Summer Day\n"+ "Suddenly sunlight fades o'er Western Hill,\nGradually moonbeams spread on Eastern Pool.\nWith hair uncombed, I lie in evening still,\nWith windows opened, I enjoy the cool.\n The lotus spreads its fragrance in the breeze,\nDew drips on the bamboo with a sound clear.\nI would play on my lute a tune to please,\nBut where can I find a connoisseur's ear?\nI think of you, my dear friend out of sight,\nBut you come into my dream at midnight.\n" ,
                                      "2.Let us appreciate the beauty of summer in the poem written by Wang Wei.\n "+ "        In My Lodge At WANG CHUAN After a Long Rain \nThe woods have stored the rain and slow comes the smoke,\nAs rice is cooked on faggots and carried to the fields.\nOver the quiet marsh-land flies a white egret,\nAnd mango-birds are singing in the full summer trees.\nI have learned to watch in peace the mountain morningglories,\nTo eat split dewy sunflower-seeds under a bough of pine.\nTo yield the post of honour to any boor at all,\nWhy should I frighten sea gulls， even with a thought？\n",
                                      "3.Let us appreciate the beauty of summer in the poem written by Gao Pin.\n "+ "       A Pavilion in the Mountain on a Summer Day\n"+ "The summer day's as long as the green shade's cool,\nThe pavilion casts its shadow into the pool.\nThe gentle breeze ripples the water crystal-clear,\nThe trellis of roses spreads fragrance far and near.\n",
                                      "4.Let us appreciate the beauty of summer in the poem by Liu Changqin.\n "+ "       Seeing off a Recluse\n"+ "Green, green the temple amid bamboos\nLate, late bell rings out the evening.\nAlone, he's lost in mountains blue,\nWith sunset his hat is carrying.\n",
                                      "5.Let us appreciate the beauty of summer in the poem written by Wang Changlin.\n "+ "       Lotus Plucking\n"+ "Her silk skirt blends with the lotus leaves green,\nThe tender buds burst with her face between,\nTheir mingling in the pond dazzles the eye.\nOnly her song tells her that she’s coming by.\n",
                  
                           };
          String []AutumnResponses={  "1.Let us appreciate the beauty of autumn in the poem written by Du Mu.\n "+ "         Mountain Trip\n"+"Winding up the rocky path in cold mountain far,\nHomesteads unveiled in the floating white clouds.\nStopped the coach to enjoy the late maple woods,\nFrosty leaves redder than the February flowers.\n" ,
                                      "2.Let us appreciate the beauty of autumn in the poem written by Liu Yuxi.\n "+ "        Song of Autumn\n"+"Since olden days we feel in autumn sad and drear,\nBut I say spring cannot compete with autumn clear.\nOn a fine day a crane cleaves the clouds and soars high,\nIt leads the poet’s lofty mind to azure sky.\n",
                                      "3.Let us appreciate the beauty of autumn in the poem written by Li Bai.\n "+ "        Midnight Song—Autumn\n"+"Moonlight is spread all o'er the capital,\nThe sound of beating clothes far and near.\nIs brought by autumn wind which can't blow all,\nThe longing away for far-off frontier.\nWhen can we beat the foe on battleground,\nSo that our men may come back safe and sound?\n",
                                      "4.Let us appreciate the beauty of autumn in the poem written by Wang Wei.\n "+ "        Autumn Evening in the Mountains\n"+"After fresh rain in mountains bare,\nAutumn permeates evening air.\nAmong pine-trees bright moonbeams peer,\nOver crystal stones flows water clear.\nBamboos whisper of washer-maids,\nLotus stirs when fishing boat wades.\nThough fragrant spring may pass away,\nStill here's the place for you to stay.\n",
                                      "5.Let us appreciate the beauty of autumn in the poem autumn written by Du Fu.\n "+ "        On the Height\n"+"The wind so swift, the sky so wide, apes wail and cry,\nWater so clear and beach so white, birds wheel and fly.\nThe boundless forest sheds its leaves shower by shower,\nThe endless river rolls its waves hour after hour.\nA thousand miles from home, I'm grieved at autumn's plight,\nIll now and then for years, alone I'm on this height.\nLiving in times so hard, at frosted hair I pine,\nCast down by poverty, I have to give up wine.\n",
                           };
           String []WinterResponses={ "1.Let us appreciate the beauty of winter in the poem written by Zu Yong.\n "+ "         Looking at Snows on Zhongnan Mountain\n"+"The shady side of Zhongnan is a charm\nPeak snows float over clouds like white long arm.\nOn mount woods after snow the sun shines bright,\nIn town the men's feel colder still at night\n",
                                      "2.Let us appreciate the beauty of winter written by Bai Juyi.\n "+ "         Asking Liu Shijiu\n"+"Green Ants a newly brew,\nRed clay miniature stove.\nWith dusk, the snow impending,\nCare to have a cup, or no?\n",
                                      "3.Let us appreciate the beauty of winter written by Liu Zongyuan.\n "+ "         Fishing in Snow\n"+"From hill to hill no bird in flight,\nFrom path to path no man in sight.\nA straw-cloak’d man afloat, behold!\nIs fishing snow in river cold.\n",
                                      "4.Let us appreciate the beauty of winter written by Liu Chaingqin.\n "+ "         The Lodge at Mt Hibiscus On A Snowy Night\n"+"Dusk falls, green hills look blurred and far,\nClime cold, the thatched huts poor and low.\nDogs’ barks heard at the wood fence gate,\nThe host is back, through wind and snow.\n",
                                      "5.Let us appreciate the beauty of winter written by Gao Shi.\n "+ "        Farewell to Dongda\n"+"Yellow clouds covering a thousand li and the sun setting dim,\nIn whirling snow the north wind drives south the wild geese.\nOn the road ahead surely will be friends dear and true,\nThroughout the land is there anyone who knows not you?\n",
                           
           };
           
	   if(nowUserIntent!=null&&nowUserIntent.getIntentName().equals("FamousPoet")) {
			
                       if(nowConversationalAction.equals("answer_poetnumber")) {
                         
                          String nowNameNumber = (String)nowUserIntent.getLastestSlotValue("poetNumber");
                          if (Integer.valueOf(nowNameNumber)<1 || Integer.valueOf(nowNameNumber) >5 ){
                              return "Please input number between 1-5";
                          }
                          int numberOfPoetry = Integer.valueOf(nowNameNumber)-1;
                          String nowPoet = (String)nowUserIntent.getLastestSlotValue("name");
                          if (nowPoet.equals("Li Bai")){
                                return LibaiResponses[ numberOfPoetry];
                          }
                          else if (nowPoet.equals("Du Fu")){
                                return DufuResponses[ numberOfPoetry];
                           }
                          else if (nowPoet.equals("Bai Juyi")){
                                return BaijuyiResponses[ numberOfPoetry];
                           }
                          else if (nowPoet.equals("Wang Wei")){
                                return WangweiResponses[ numberOfPoetry];
                           }
                          else if (nowPoet.equals("Liu Yuxi")){
                                return LiuyuxiResponses[ numberOfPoetry];  
                           }
			}else if(nowConversationalAction.equals("ask-name")) {
                                   return "Li Bai, Du Fu, Bai Juyi, Wang Wei, Liu Yuxi, which one would you like to know?";   
			}else if(nowConversationalAction.equals("ask-poetnumber")){
                             String nowPoet = (String)nowUserIntent.getLastestSlotValue("name"); 
                             String introduce = null;
              
                              if (nowPoet.equals("Li Bai"))
                                       introduce ="Li Bai is a great romantic poet, known as Poet Immortal. He is often regarded, along with Du Fu, as one of the two greatest poets in China's literary history. A large number of poems till survive today, they have been translated into many languages all over the world.";
			      if (nowPoet.equals("Du Fu"))
                                       introduce ="Du Fu is a great realist poet, known as \"Poet-Sage\". He is often described as a poet-historian, and his works convey the emotional impact and import of political and social issues and register a range of private concerns, trials, and dramas. His poems are remarkable for their range of moods as well as contents.";
                              if (nowPoet.equals("Bai Juyi"))
                                       introduce ="Bai Juyi was one of the most prolific of all Chinese poets. Many of his poems concern his career or observations made about everyday life,  He achieved fame as a writer of verse in a low-key, near vernacular style that was popular throughout China, in Korea and Japan.";
                              if (nowPoet.equals("Wang Wei"))
                                       introduce ="Wang Wei was a painter, calligrapher and musician as well as being one of the greatest High Tang poets. His works often take a Buddhist perspective, combining an attention to the beauties of nature with an awareness of sensory illusion.";
                              if (nowPoet.equals("Liu Yuxi"))
                                       introduce ="Liu Yuxi  is the famous poets in the Tang Dynasty. His poetry is concise and lucid with eminent style. His poetry is penetrated by a wisdom of philosophers and deep feelings of poets, rich in very artistic tension and majestic and upright momentum.";
                              return introduce + "I will introduce his five famous works.Please input number between 1-5.\n";
                        } else {
				return "You want to know the famous poet,please talk to me more";  
			}
		}else if(nowUserIntent!=null&&nowUserIntent.getIntentName().equals("FamousPoetry")){
                       
                        if(nowConversationalAction.equals("answer_poemnumber")) {
                            String nowPoetry = (String)nowUserIntent.getLastestSlotValue("poemNumber");
                            int numberOfPoetry = Integer.valueOf(nowPoetry)-1;
			    return fiftyPoetyResponses[numberOfPoetry];
                          // return fiftyPoetyResponses[(int)nowUserIntent.getLastestSlotValue("poemNumber")-1];
                        
			}else  if(nowConversationalAction.equals("answer_poemtype")) {
                             String responsePotry =null;
                             String type = (String)nowUserIntent.getLastestSlotValue("poemType");
                             if (type.equals("moon")){
                                  int randomNumber=(int) (Math.random()* moonResponses.length);
                                  responsePotry = moonResponses[randomNumber];
                             }
                             if (type.equals("friendship")){
                                  int randomNumber=(int) (Math.random()* friendshipResponses.length);
                                  responsePotry = friendshipResponses[randomNumber];
                             }
			     return  responsePotry; 
			}else if(nowConversationalAction.equals("ask-poemnumber")) {
				return "I have prepared 50 famous poems for you, please input any number between 1-50"; 
			}else {
				return "Sorry I don't know how to respond to something like that."; 
			}
                      
		}else if(nowUserIntent!=null&&nowUserIntent.getIntentName().equals("SeasonPoetry")){
                       
                        if(nowConversationalAction.equals("answer_season")) {
                          
                            String nowSeason = (String)nowUserIntent.getLastestSlotValue("season");
                            String responsePotry =null;
                            if (nowSeason.equals("spring")){
                              int randomNumber=(int) (Math.random()* SpringResponses.length);
                              responsePotry = SpringResponses[randomNumber];
                            }
                           else if (nowSeason.equals("summer")){
                              int randomNumber=(int) (Math.random()* SummerResponses.length);
                              responsePotry = SummerResponses[randomNumber];
                            }
                           else if (nowSeason.equals("autumn") || nowSeason.equals("fall")){
                             int randomNumber=(int) (Math.random()* AutumnResponses.length);
                              responsePotry = AutumnResponses[randomNumber];
                            }
                           else if (nowSeason.equals("winter")){
                              int randomNumber=(int) (Math.random()* WinterResponses.length);
                              responsePotry =WinterResponses[randomNumber];
                            }
                            return responsePotry ;
			}else if(nowConversationalAction.equals("ask-season")) {
				return "Which season would you like to know? Spring,Summer,Autumn,Winter"; 
			}else {
				return "Sorry I don't know how to respond to something like that."; 
			}
                      
		}
                else{
		  return "Hello, nice to meet you.Please talk to me about the Tang poetry and poet";  //[Intent = ?, Action = ?]
		}
		
		return "";
		
	}

}

